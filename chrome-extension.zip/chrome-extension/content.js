// Detect form fields and fetch auto-fill data
async function fillForm() {
    const formFields = document.querySelectorAll('input, textarea, select');

    // Replace the URL below with your backend endpoint
    const response = await fetch('http://localhost:5055/api/get_tax_form_data');
    const data = await response.json();

    formFields.forEach(field => {
        if (data[field.name]) {
            field.value = data[field.name];
        }
    });
}

fillForm();
