document.getElementById('fillForms').addEventListener('click', () => {
    chrome.scripting.executeScript({
        target: {tabId: activeTabId},
        function: fillForm
    });
});
